#include "create.h"
#include <stdio.h>
#include <string.h>


int main() {
    // Test adding a subject
    struct Subject subject;
    printf("Enter a subject name to add: ");
    fgets(subject.subjectName, MAX_SUBJECT_LENGTH, stdin);
    // Remove newline character if present
    if (subject.subjectName[strlen(subject.subjectName) - 1] == '\n') {
        subject.subjectName[strlen(subject.subjectName) - 1] = '\0';
    }

    addSubject(subject);


    return 0;
}

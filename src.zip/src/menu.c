//
// Created by Quinn Thompson on 2023-11-18.
//
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "create.h"
#include "common.h"
#define SCREEN_CLEARING 1
#define MAX_INPUT_LENGTH 100


void mainMenu() {
    if (SCREEN_CLEARING) {
        system("cls");
    }
    printf("=============================\n");
    printf("=== Welcome To QuizMaster ===\n");
    printf("=============================\n\n");

    printf("1) Create Subject\n");
    printf("2) Add New Question\n");
    printf("3) Edit Existing Question\n");
    printf("4) Delete Subject\n");
    printf("5) Take a Quiz\n");
    printf("6) Exit\n\n");

    printf("Option: ");
}

void addSubjectMenu() {
    if (SCREEN_CLEARING) {
        system("cls");
    }
    printf("====================\n");
    printf("=== Add Subjects ===\n");
    printf("====================\n\n");
    struct Subject new_subject;
    printf("Enter New Subject Name: \n");
    fgets(new_subject.subjectName, MAX_SUBJECT_LENGTH, stdin);
    // Remove newline character if present
    if (new_subject.subjectName[strlen(new_subject.subjectName) - 1] == '\n') {
        new_subject.subjectName[strlen(new_subject.subjectName) - 1] = '\0';
    }

    addSubject(new_subject);
}

bool boolAddQuestionMenu(struct Subject *new_subject) {
    if (SCREEN_CLEARING) {
        system("cls");
    }


    printf("=====================\n");
    printf("=== Add Questions ===\n");
    printf("=====================\n\n");

    printf("Enter the Subject: \n");
    fgets(new_subject->subjectName, MAX_SUBJECT_LENGTH, stdin);
    // Remove newline character if present
    if (new_subject->subjectName[strlen(new_subject->subjectName) - 1] == '\n') {
        new_subject->subjectName[strlen(new_subject->subjectName) - 1] = '\0';
    }
    fflush(stdin);

    // Check if subject exist
    if (doesSubjectExist(*new_subject)) {
        return true;
    } else {
        printf("Subject not found.\n");
        return false;
    }
}

struct Quiz getNewQuestion()


    {
        struct Quiz new_quiz;
        printf("\n\nEnter the Question: \n");
        fgets(new_quiz.question, MAX_INPUT_LENGTH, stdin);


        if (new_quiz.question[strlen(new_quiz.question) - 1] == '\n') {
            new_quiz.question[strlen(new_quiz.question) - 1] = '\0';
        }


        printf("\nEnter the Question's Answer: \n");
        fgets(new_quiz.answer, MAX_INPUT_LENGTH, stdin);

        if (new_quiz.answer[strlen(new_quiz.answer) - 1] == '\n') {
            new_quiz.answer[strlen(new_quiz.answer) - 1] = '\0';
        }
        return new_quiz;
    }

void addQuestionMenu(){

    struct Subject new_subject;
    if (boolAddQuestionMenu(&new_subject)){
        char input[MAX_INPUT_LENGTH];
        do {
            struct Quiz new_quiz = getNewQuestion();
            addQuiz(new_subject, new_quiz);

            printf("Would you like to add more?\n");
            printf("1. Yes\n");
            printf("2. No\n");
            fgets(input, MAX_INPUT_LENGTH, stdin); // Get user input

            // Remove newline character if present
            if (input[strlen(input) - 1] == '\n') {
                input[strlen(input) - 1] = '\0';
            }

            // Check if the user wants to exit the loop
            if (strcmp(input, "2") == 0) {
                break;
            }

        } while (strcmp(input, "1") == 0); // Continue if the user inputs "1"
    }
}


struct Question getQuestion(char * subject) {
    struct Question newQuestion;
    newQuestion.number = 2;
    strcpy_s(newQuestion.content, 100, "What's one plus one?");
    strcpy_s(newQuestion.answer, 100, "Two.");

    return newQuestion;
}

void deleteSubjectMenu() {
    if (SCREEN_CLEARING) {
        system("cls");
    }

    char subject[MAX_INPUT_LENGTH];
    char input[MAX_INPUT_LENGTH];
    char confirmation[] = "confirm";

    printf("======================\n");
    printf("=== Delete Subject ===\n");
    printf("======================\n\n");

    printf("Subject: ");
    scanf("%s", subject);

    printf("\nType 'confirm' to confirm.\n");
    scanf("%s", input);

    if (strcmp(input, confirmation) == 0) {
        printf("Deleting %s...", subject);//call to delete subject
    }
}

struct Question editQuestionMenu() {
    if (SCREEN_CLEARING) {
        system("cls");
    }

    char subject[MAX_INPUT_LENGTH];
    char questionNumber[MAX_INPUT_LENGTH];
    char input[MAX_INPUT_LENGTH];

    printf("=====================\n");
    printf("=== Edit Question ===\n");
    printf("=====================\n\n");

    printf("Subject: ");
    scanf("%s", subject);
    printf("Question Number: ");
    scanf("%s", questionNumber);


    struct Question oldQuestion = getQuestion(subject);
    struct Question newQuestion;
    newQuestion.number = oldQuestion.number;

    printf("\n\n[ Question %d ]\n", oldQuestion.number);
    printf("%s --- Change[Y/N] ", oldQuestion.content);
    scanf("%s", input);

    fflush(stdin);

    if (strcmp(input, "Y") == 0) {
        printf("\nNew Content: \n");
        fgets(input, MAX_INPUT_LENGTH, stdin);
        strcpy(newQuestion.content, input);
    } else {
        strcpy(newQuestion.content, oldQuestion.content);
    }

    printf("\n%s --- Change[Y/N] ", oldQuestion.answer);
    scanf("%s", input);

    fflush(stdin);

    if (strcmp(input, "Y") == 0) {
        printf("\nNew Answer: \n");
        fgets(input, MAX_INPUT_LENGTH, stdin);
        strcpy(newQuestion.answer, input);
    } else {
        strcpy(newQuestion.answer, oldQuestion.answer);
    }

    return newQuestion;
}

void printQuestion(struct Question question) {
    if (SCREEN_CLEARING) {
        system("cls");
    }
    printf("[ Question %d ]\n", question.number);
    printf("%s\n\n", question.content);

    printf("1) Show Answer\n");
    //placeholder; replace 100 with the number of questions for the current subject
    if (question.number > 1 && question.number < 100) {
        printf("2) Previous\n");
        printf("3) Next\n");
    } else if (question.number == 100) { //&& 1 != max question number
        printf("2) Previous\n");
    } else if (question.number == 1){ //&& 1 != max question number
        printf("2) Next\n");
    }

    printf("\nOption: ");
}

void printAnswer(struct Question question) {
    if (SCREEN_CLEARING) {
        system("cls");
    }
    printf("[ Answer %d ]\n", question.number);
    printf("%s\n\n", question.answer);

    printf("1) Hide Answer\n");

    //placeholder; replace 100 with the number of questions for the current subject
    if (question.number > 1 && question.number < 100) {
        printf("2) Previous\n");
        printf("3) Next\n");
    } else if (question.number == 100) { //&& 1 != max question number
        printf("2) Previous\n");
    } else if (question.number == 1){ //&& 1 != max question number
        printf("2) Next\n");
    }
    printf("\nOption: ");
}

void quizMenu() {
    if (SCREEN_CLEARING) {
        system("cls");
    }

    char subject[MAX_INPUT_LENGTH];
    int running = 1;
    int isAnswer = 0;

    printf("==================\n");
    printf("=== Quiz Mode! ===\n");
    printf("==================\n\n");

    printf("Subject: ");
    scanf("%s", subject);

    printf("\n\n");

    char input[MAX_INPUT_LENGTH];
    struct Question question = getQuestion(subject);

    char viewAnswerCode[2] = "1";
    char backCode[2] = "2";
    char nextCode[2] = "3";
    char exitCode[5] = "back";

    do {
        if (isAnswer) {
            printAnswer(question);
        } else {
            printQuestion(question);
        }
        scanf("%s", input);

        if (question.number == 1) {
            nextCode[0] = '2';
            backCode[0] = '\0';
        } else if (question.number == 100) {
            nextCode[0] = '\0';
            backCode[0] = '2';
        } else {
            nextCode[0] = '3';
            backCode[0] = '2';
        }

        if (strcmp(input, viewAnswerCode) == 0) {
            isAnswer = !isAnswer;
        } else if (strcmp(input, backCode) == 0) {
            question = getQuestion(subject);//get previous question
        } else if (strcmp(input, nextCode) == 0) {
            question = getQuestion(subject);//get next question
        } else if (strcmp(input, exitCode) == 0) {
            running = 0;
        }
    } while (running);
}

void menu() {
    int running = 1;

    //Option Codes
    char addSubjectCode[2] = "1";
    char addQuestionCode[2] = "2";
    char editQuestionCode[2] = "3";
    char deleteSubjectCode[2] = "4";
    char playQuizCode[2] = "5";
    char exitCode[2] = "6";
    char input[MAX_INPUT_LENGTH];

    do {
        printf("<< input: '%s' >>\n\n", input);
        mainMenu();
        scanf("%s", input);
        if (strcmp(input, addSubjectCode) == 0) {
            addSubjectMenu();
        } else if (strcmp(input, addQuestionCode) == 0) {
            addQuestionMenu();
        } else if (strcmp(input, editQuestionCode) == 0) {
            editQuestionMenu();
        } else if (strcmp(input, deleteSubjectCode) == 0) {
            deleteSubjectMenu();
        } else if (strcmp(input, playQuizCode) == 0) {
            quizMenu();
        } else if (strcmp(input, exitCode) == 0) {
            running = 0;
            printf("<< attempting to terminate program >>");
        }
    } while (running);
}

int main () {
    menu();
    return 0;
}